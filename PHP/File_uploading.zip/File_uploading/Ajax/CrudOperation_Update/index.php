<form method="post" enctype="multipart/form-data">
    <input type="text" placeholder="Enter Your Name" name="name"><br>
    <input type="text" placeholder="Enter Your Email" name="email"><br>
    <input type="text" placeholder="Enter Your Password" name="password"><br>
    <input type="text" placeholder="Enter Your Address" name="address"><br>
    <input type="text" onclick="this.type='file'" placeholder="Upload Profile Picture" name="profilePic"><br>
    
    <input type="submit" name="login">
</form>

<?php   

if(isset($_POST['login'])){
   
// Get File 
$file_name = $_FILES['profilePic'] ['name'];
$file_size = $_FILES['profilePic'] ['size'];
$file_tmp_name = $_FILES['profilePic'] ['tmp_name'];
$file_type=pathinfo($file_name,PATHINFO_EXTENSION); 

$destination="profile_images/".$file_name;


move_uploaded_file($file_tmp_name,$destination);


if($file_size <=2000000){
    echo "size match";
}else{
    echo "Not match";
}




//    $con = mysqli_connect("localhost","root","","fullstack");
//     //Insert Query
//     // '".$_POST['name']."'

//    $query =  mysqli_query($con,"INSERT INTO users (name,email,password,address)VALUES('".$_POST['name']."','".$_POST['email']."','".$_POST['password']."','".$_POST['address']."')");


//    if($query){
//     echo "<script>
//         alert('Data Inserted Successfully')
//     </script>";
//    }

}


?>

