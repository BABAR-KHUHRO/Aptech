<?php 
$con = mysqli_connect("localhost","root","","fullstack");
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>CRUD OPERATION</title>
</head>
<body class="bg-primary">
<center>  <h1 class="bg-success text-light pb-0 mb-0">Users List</h1></center>

<form class="d-flex flex-row justify-content-end p-1" style="display:flex" method="post"> 
<input class="p-0 m-0 " type="search" name="db_search" id="db_search_id" >

<button type="submit" name="search" >Search</button>
</form>
<!-- <center><h3>Search Results:</h3></center> -->


        <?php 
        if(isset($_POST['search'])){
                $search_query=$_POST['db_search'];
                    $query = mysqli_query($con,"SELECT * FROM users WHERE name LIKE '%$search_query%' OR email LIKE '%$search_query%'");
                        ?>
<table class="table text-light"  style="border: 2px solid white">
            <tr style="border: 2px solid white; text-align:center">
                <th style="border: 2px solid white">Sno</th>
                <th style="border: 2px solid white">Name</th>
                <th style="border: 2px solid white">Email</th>
                <th style="border: 2px solid white">Address</th>
<th style="border: 2px solid white">Action</th>
            </tr>



<?php


                    if(mysqli_num_rows($query) > 0){
                        $sno = 1;
                            foreach($query as $value){
                            ?>
                            <tr style="border: 2px solid white ;text-align:center">
                                <td style="border: 2px solid white"><?php echo $sno ?></td>
                                <td style="border: 2px solid white"><?php echo $value['name'] ?></td>
                                <td style="border: 2px solid white"><?php echo $value['email'] ?></td>
                                <td style="border: 2px solid white"><?php echo $value['address'] ?></td>
                                <td style="border: 2px solid white">
                                <button class="btn btn-danger"  data-bs-toggle="modal" data-bs-target="#deleteUser_<?php echo $value['id'] ?>">Delete</button>
                                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editUser_<?php echo $value['id'] ?>">Edit</button>
                            </td>
 
                            </tr>
    

                        <!-- Delete Model -->

                        <div class="modal fade" id="deleteUser_<?php echo $value['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content"> 
        <form method="post">
            <div class="modal-header">
                
                <h5 class="modal-title" id="exampleModalLabel">DELETE</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" value="<?php echo $value['id'] ?>">
            <h3>Are You Want To Delete Data?</h3>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="delete" class="btn btn-danger">Delete</button>
            </div>
      </form>
    </div>
  </div>
</div>



<!-- Edit Model -->


<div class="modal fade" id="editUser_<?php echo $value['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content"> 
        <form method="post">
            <div class="modal-header">
                
                <h5 class="modal-title" id="exampleModalLabel">EDIT</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" value="<?php echo $value['id'] ?>">
                            
                <input type="text" class="form-control mb-3" placeholder="Name" name="name" value="<?php echo $value['name'] ?>">

                 <input type="email" class="form-control mb-3" placeholder="Email" name="email" value="<?php echo $value['email'] ?>">
                 
                  <input type="text" class="form-control mb-3" placeholder="Password" name="password" value="<?php echo $value['password'] ?>">

                   <input type="text" class="form-control mb-3" placeholder="Address" name="address" value="<?php echo $value['address'] ?>">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="update" class="btn btn-success">Update</button>
            </div>
      </form>
    </div>
  </div>
</div>






                            <?php
                            $sno++;
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="4">No Results Found!</td>
                        </tr>

                        <?php 

                    }
        

                }


                if(isset($_POST['delete'])){
                
                    $query = mysqli_query($con,"DELETE FROM users WHERE id = '".$_POST['id']."'");
    
                    if($query){
                        echo "<script>
                            alert('Data Deleted Successfully')
                            location.assign('search.php')
                        </script";
                    }
                }
    
    
                // Update Code
    
                if(isset($_POST["update"])){
                    
                               // $name = "abc";
                // $name = "Updated";

                $query = mysqli_query($con,"UPDATE users SET name='".$_POST['name']."',email='".$_POST['email']."',password='".$_POST['password']."',address='".$_POST['address']."' WHERE id = '".$_POST['id']."'");


                if($query){


                    echo "<script>
                        alert('Data Updated Successfully')
                        location.assign('search.php')
                    </script";
            }
   
            }
    
    
?>
</table>
<script src="js/bootstrap.min.js"></script>

   
  </body>
</html>