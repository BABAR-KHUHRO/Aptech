<?php 
$con = mysqli_connect("localhost","root","","fullstack");
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>CRUD OPERATION</title>
  </head>
  <body>
    <div>

<form style="display:flex" method="post"> 

<input  type="search" name="db_search" id="db_search_id" >

<button type="submit" name="search" >Search</button>
</form>

<?php

if(isset($_POST['search'])){
    // error_reporting(0);

  
    $search_query=$_POST['db_search'];

    $query = mysqli_query($con,"SELECT count(employee_id) as `count` FROM `employee_list` where `code` = '{$code}' ".($id > 0 ? " and employee_id != '{$id}'" : ""))->fetch_array()['count'];
                if($check >0){
                    $resp['status']="failed";
                    $resp['msg'] = "Employee Code is already exists.";

                }
        }


?>

    <!-- Option 1: Bootstrap Bundle with Popper -->
<script src="js/bootstrap.min.js"></script>

</body>
</html>